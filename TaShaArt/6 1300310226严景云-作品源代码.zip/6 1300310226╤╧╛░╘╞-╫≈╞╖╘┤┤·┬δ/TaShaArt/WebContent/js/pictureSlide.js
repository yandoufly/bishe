var Carousel = function(oDivSelector,oUlSelector,oBtn1Selector,oBtn2Selector){
	this.oDivSelector=oDivSelector;
	this.oUlSelector=oUlSelector;
	this.oBtn1Selector=oBtn1Selector;
	this.oBtn2Selector=oBtn2Selector;
	this.oDiv= null;
	this.oUl= null;
	this.speed= 2;
	this.oLi= null;
	this.liWidth=null;
	this.oBtn1= null;
	this.oBtn2= null;
	this.timer= null;
	this.init= function() {
		//初始化赋值
		this.oUl=document.querySelector(this.oUlSelector);
		this.oDiv=document.querySelector(this.oDivSelector);
		this.oUl.innerHTML += this.oUl.innerHTML;
		this.oBtn1=document.querySelector(this.oBtn1Selector);
		this.oBtn2=document.querySelector(this.oBtn2Selector);
		this.oLi=document.querySelectorAll(this.oUlSelector+' li');
		this.liWidth=parseInt(getComputedStyle(this.oLi[0]).width);
		this.oUl.style.width = this.oLi.length * this.liWidth + 'px';
		this.oBtn1.addEventListener('click', function() {
			this.speed = -Math.abs(this.speed);
		}.bind(this), false);
		this.oBtn2.addEventListener('click', function() {
			this.speed = Math.abs(this.speed);
		}.bind(this), false);
		this.timer = setInterval(this.move.bind(this), 60);
		this.oDiv.addEventListener('mouseout', function() {
			this.timer = setInterval(this.move.bind(this), 60);
		}.bind(this), false);
		this.oDiv.addEventListener('mousemove', function() {
			clearInterval(this.timer); //鼠标移入清除定时器
		}.bind(this), false);

	};
	this.move= function() {
		if(this.oUl.offsetLeft < -(this.oUl.offsetWidth / 2)) { //向左滚动，当靠左的图4移出边框时
			this.oUl.style.left = 0;
		}
		if(this.oUl.offsetLeft > 0) { //向右滚动，当靠右的图1移出边框时
			this.oUl.style.left = -(this.oUl.offsetWidth / 2) + 'px';
		}
		this.oUl.style.left = this.oUl.offsetLeft + this.speed + 'px';
	}
}