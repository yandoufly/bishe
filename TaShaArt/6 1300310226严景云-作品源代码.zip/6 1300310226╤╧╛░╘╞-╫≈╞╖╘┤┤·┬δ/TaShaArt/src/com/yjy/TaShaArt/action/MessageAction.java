package com.yjy.TaShaArt.action;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Message;
import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.service.MessageService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class MessageAction extends BaseAction {
	@Resource
	private MessageService messageService;
	private Message message;
	
	public void findByIdMessageShow() throws IOException {
		message = messageService.findObjectById(message.getId());
		JSONArray jsonArray = JSONArray.fromObject(message); //得到数据
		System.out.println(jsonArray);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}
	
	//页面显示需要的数据
	public void findMessageShow() throws IOException{
		
		QueryHelper queryHelper = new QueryHelper(Message.class, "m");
		queryHelper.addCondition("m.publish=?", true);
		pageResult = messageService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(jsonArray2);
		jsonArray.add(pageResult.getPageNo());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
		
	}

	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(Message.class, "m");
		try {
			pageResult = messageService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//保存新增
	public void add() throws Exception{
		if(message != null){
			System.out.println(message);
			messageService.save(message);
		}
	}
	//跳转到编辑页面
	public String editUI(){
		if (message != null && message.getId() != null) {
			message = messageService.findObjectById(message.getId());
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(message != null){
			messageService.update(message);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(message != null && message.getId() != null){
			messageService.delete(message.getId());
		}
		return "list";
	}
	//批量删除
	public String deleteSelected(){
		if(selectedRow != null){
			for(int id: selectedRow){
				System.out.println("delete id:" + id);
				messageService.delete(id);
			}
		}
		return "list";
	}
	
	public Message getMessage() {
		return message;
	}
	public void setMessage(Message message) {
		this.message = message;
	}
}
