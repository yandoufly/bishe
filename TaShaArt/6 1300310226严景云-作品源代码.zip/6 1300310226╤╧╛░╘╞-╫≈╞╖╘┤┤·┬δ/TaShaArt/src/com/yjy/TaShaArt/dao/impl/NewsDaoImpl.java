package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.NewsDao;
import com.yjy.TaShaArt.entity.News;

public class NewsDaoImpl extends BaseDaoImpl<News> implements NewsDao {

}
