package com.yjy.TaShaArt.action;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Teacher;
import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.entity.Video;
import com.yjy.TaShaArt.service.VideoService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class VideoAction extends BaseAction {
	@Resource
	private VideoService videoService;
	private Video video;
	
	//头像
	private File myVideoImg;
	private String myVideoImgContentType;
	private String myVideoImgFileName;
	
	public void findVideoShow() throws IOException {
		QueryHelper queryHelper = new QueryHelper(Video.class, "v");
		pageResult = videoService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(jsonArray2);
		jsonArray.add(pageResult.getPageNo());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
		
		
		/*List<Video> list = videoService.findObjects();
		JSONArray jsonArray = JSONArray.fromObject(list); //得到数据
		
		System.out.println(jsonArray);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());*/
		
	}
	
	public String findVidoeShow() throws IOException{
		if(video != null && video.getId() != null) {
			video = videoService.findObjectById(video.getId());
			ServletActionContext.getRequest().setAttribute("video", video);
			return "videoShow";
		}
		return null;
	}
	
	//视频列表
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(Video.class, "v");
		pageResult = videoService.getPageResult(queryHelper, getPageNo(), getPageSize());
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(video != null){

			//处理头像
			if(myVideoImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/videoImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + myVideoImgFileName.substring(myVideoImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(myVideoImg, new File(filePath1, fileName));
				video.setVideoImg("upload/videoImg/" + fileName);
			}
			
			video.setCreateTime(new Date());
			video.setScanCount(1033);
			videoService.save(video);
		}
		return "list";
	}
	//跳转到编辑页面
	public String editUI(){
		if (video != null && video.getId() != null) {
			video = videoService.findObjectById(video.getId());
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(video != null){
			videoService.update(video);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(video != null && video.getId() != null){
			videoService.delete(video.getId());
		}
		return "list";
	}
	//批量删除
	public String deleteSelected(){
		if(selectedRow != null){
			for(int id: selectedRow){
				System.out.println("delete id:" + id);
				videoService.delete(id);
			}
		}
		return "list";
	}
	
	public Video getVideo() {
		return video;
	}
	public void setVideo(Video video) {
		this.video = video;
	}

	public File getMyVideoImg() {
		return myVideoImg;
	}
	public void setMyVideoImg(File myVideoImg) {
		this.myVideoImg = myVideoImg;
	}
	public String getMyVideoImgContentType() {
		return myVideoImgContentType;
	}
	public void setMyVideoImgContentType(String myVideoImgContentType) {
		this.myVideoImgContentType = myVideoImgContentType;
	}
	public String getMyVideoImgFileName() {
		return myVideoImgFileName;
	}
	public void setMyVideoImgFileName(String myVideoImgFileName) {
		this.myVideoImgFileName = myVideoImgFileName;
	}
}
