package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Teacher;

public interface TeacherService extends BaseService<Teacher>{

}
