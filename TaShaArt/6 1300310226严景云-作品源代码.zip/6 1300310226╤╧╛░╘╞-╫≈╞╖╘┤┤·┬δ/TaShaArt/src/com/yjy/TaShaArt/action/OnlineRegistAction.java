package com.yjy.TaShaArt.action;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.OnlineRegist;
import com.yjy.TaShaArt.entity.Video;
import com.yjy.TaShaArt.service.OnlineRegistService;
import com.yjy.TaShaArt.util.QueryHelper;
import com.yjy.TaShaArt.util.SendMail;

import net.sf.json.JSONObject;

public class OnlineRegistAction extends BaseAction {
	@Resource
	private OnlineRegistService onlineRegistService;
	private OnlineRegist onlineRegist;
	
	private String authCode;
	
	//发送邮件
	public void sendMyMail() throws Exception{
		Map<String, String> map = new HashMap<String, String>();
		SendMail mail = new SendMail("326015540@qq.com", "jpxicmbuuxkfbhgd"); // 用户名&&验证码
		map.put("mail.smtp.host", "smtp.qq.com"); // 指定发送邮件的主机为 smtp.qq.com
		map.put("mail.smtp.auth", "true"); // 开启认证

		// 处理错误：530 Error: A secure connection is requiered(such as ssl)”
		map.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		map.put("mail.smtp.port", "465");
		map.put("mail.smtp.socketFactory.port", "465");
		
		mail.setPros(map);
		mail.initMessage();
		
		//添加收件人邮箱
		mail.setRecipient(onlineRegist.getEmail());
		
		mail.setSubject("网上注册验证码验证"); // 邮件主题.
		mail.setDate(new Date()); // 邮件时间
		mail.setFrom("塔莎艺术培训学校");  //发送人名字
		int authCode = (int)((Math.random()*9+1)*100000); //随机生成六位数
		System.out.println(authCode); 
		
		mail.setContent(String.valueOf(authCode) , "text/html; charset=UTF-8"); //正文部分
//		ServletActionContext.getRequest().getSession().setAttribute("authCode", String.valueOf(authCode));
		
		String message = mail.sendMessage(); //发送邮件
		System.out.println(message);
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html; charset=utf-8");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("authCode", String.valueOf(authCode));
		jsonObject.put("msg", "已经发送邮件到"+onlineRegist.getEmail() + "中，请查看验证码");
		response.getWriter().println(jsonObject);
	}
	
	//网上报名注册
	public void addOnlineRegist() throws IOException{
		if(onlineRegist != null) {
			System.out.println(onlineRegist);
			onlineRegistService.save(onlineRegist);
		}
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html; charset=utf-8");
		response.getWriter().println("报名成功，届时请留言你填写的邮箱及手机短信");
	}
	
	//视频列表
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(OnlineRegist.class, "o");
		pageResult = onlineRegistService.getPageResult(queryHelper, getPageNo(), getPageSize());
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}
	
	public OnlineRegist getOnlineRegist() {
		return onlineRegist;
	}
	public void setOnlineRegist(OnlineRegist onlineRegist) {
		this.onlineRegist = onlineRegist;
	}
	
	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}
	public String getAuthCode() {
		return authCode;
	}
}
