package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.ActivityDao;
import com.yjy.TaShaArt.entity.Activity;
import com.yjy.TaShaArt.service.ActivityService;

@Service("activityService")
public class ActivityServiceImpl extends BaseServiceImpl<Activity> implements ActivityService {
	
	private ActivityDao activityDao;
	
	@Resource 
	public void setActivityDao(ActivityDao activityDao) {
		super.setBaseDao(activityDao);
		this.activityDao = activityDao;
	}
}
