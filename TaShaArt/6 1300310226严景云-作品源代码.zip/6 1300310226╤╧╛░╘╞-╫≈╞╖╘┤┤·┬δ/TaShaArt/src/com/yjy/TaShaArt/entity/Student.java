package com.yjy.TaShaArt.entity;

public class Student {
	private Integer id;
	private String name; //学生
	private boolean gender; //性别
	private String headImg; //头像
	private String accessUniversity; //学校通知函(照片)
	private String 	specialty; //专业
	private String passSchool; //通过学校
	private String fromClass; //所在班级
	private String type; //类型：普通学生 || 明星学员 || 光荣榜
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getHeadImg() {
		return headImg;
	}
	public void setHeadImg(String headImg) {
		this.headImg = headImg;
	}
	public String getAccessUniversity() {
		return accessUniversity;
	}
	public void setAccessUniversity(String accessUniversity) {
		this.accessUniversity = accessUniversity;
	}
	public String getSpecialty() {
		return specialty;
	}
	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}
	public String getPassSchool() {
		return passSchool;
	}
	public void setPassSchool(String passSchool) {
		this.passSchool = passSchool;
	}
	public String getFromClass() {
		return fromClass;
	}
	public void setFromClass(String fromClass) {
		this.fromClass = fromClass;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", gender=" + gender + ", headImg=" + headImg
				+ ", accessUniversity=" + accessUniversity + ", specialty=" + specialty + ", passSchool=" + passSchool
				+ ", fromClass=" + fromClass + ", type=" + type + "]";
	}
}
