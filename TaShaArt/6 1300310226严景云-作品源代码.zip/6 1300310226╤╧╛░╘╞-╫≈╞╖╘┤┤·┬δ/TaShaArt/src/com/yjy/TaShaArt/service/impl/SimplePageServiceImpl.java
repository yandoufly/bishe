package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.SimplePageDao;
import com.yjy.TaShaArt.entity.SimplePage;
import com.yjy.TaShaArt.service.SimplePageService;

@Service("simplePageService")
public class SimplePageServiceImpl extends BaseServiceImpl<SimplePage> implements SimplePageService {
	
	private SimplePageDao simplePageDao;
	
	@Resource
	public void setSimplePageDao(SimplePageDao simplePageDao) {
		super.setBaseDao(simplePageDao);
		this.simplePageDao = simplePageDao;
	}
}
