package com.yjy.TaShaArt.entity;

import java.util.Date;

public class User {
	private Integer id; //主键
	private String account; //账号
	private String name; //名字
	private String password; //密码
	
	private String headImg; //头像
	private boolean gender; //性别
	private String mobile; //手机
	private String email; //邮箱
	private Date birthday; //出生日期
	private String address; //地址
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getHeadImg() {
		return headImg;
	}
	public void setHeadImg(String headImg) {
		this.headImg = headImg;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", account=" + account + ", name=" + name + ", password=" + password + ", headImg="
				+ headImg + ", gender=" + gender + ", mobile=" + mobile + ", email=" + email + ", birthday=" + birthday
				+ ", address=" + address + "]";
	}
}
