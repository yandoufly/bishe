package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.OnlineRegist;

public interface OnlineRegistDao extends BaseDao<OnlineRegist> {
	
}
