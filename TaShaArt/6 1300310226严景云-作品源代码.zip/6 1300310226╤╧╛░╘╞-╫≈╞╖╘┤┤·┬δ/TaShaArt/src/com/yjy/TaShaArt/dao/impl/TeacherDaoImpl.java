package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.TeacherDao;
import com.yjy.TaShaArt.entity.Teacher;

public class TeacherDaoImpl extends BaseDaoImpl<Teacher> implements TeacherDao {

}
