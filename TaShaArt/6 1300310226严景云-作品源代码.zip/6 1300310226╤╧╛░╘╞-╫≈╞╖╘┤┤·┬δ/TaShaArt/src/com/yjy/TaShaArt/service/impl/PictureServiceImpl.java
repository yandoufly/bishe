package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.PictureDao;
import com.yjy.TaShaArt.entity.Picture;
import com.yjy.TaShaArt.service.PictureService;

@Service("pictureService")
public class PictureServiceImpl extends BaseServiceImpl<Picture> implements PictureService {
	
	private PictureDao pictureDao;
	
	@Resource 
	public void setPictureDao(PictureDao pictureDao) {
		super.setBaseDao(pictureDao);
		this.pictureDao = pictureDao;
	}
}
