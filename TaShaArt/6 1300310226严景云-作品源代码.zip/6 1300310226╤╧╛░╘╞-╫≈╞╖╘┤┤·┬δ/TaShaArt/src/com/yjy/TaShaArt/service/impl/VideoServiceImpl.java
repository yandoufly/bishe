package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.VideoDao;
import com.yjy.TaShaArt.entity.Video;
import com.yjy.TaShaArt.service.VideoService;

@Service("videoService")
public class VideoServiceImpl extends BaseServiceImpl<Video> implements VideoService {
	
	private VideoDao videoDao;
	
	@Resource 
	public void setVideoDao(VideoDao videoDao) {
		super.setBaseDao(videoDao);
		this.videoDao = videoDao;
	}
}
