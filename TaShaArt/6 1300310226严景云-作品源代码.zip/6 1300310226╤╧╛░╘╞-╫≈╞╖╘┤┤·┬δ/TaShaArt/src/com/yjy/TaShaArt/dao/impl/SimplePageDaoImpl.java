package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.SimplePageDao;
import com.yjy.TaShaArt.entity.SimplePage;

public class SimplePageDaoImpl extends BaseDaoImpl<SimplePage> implements SimplePageDao {

}
