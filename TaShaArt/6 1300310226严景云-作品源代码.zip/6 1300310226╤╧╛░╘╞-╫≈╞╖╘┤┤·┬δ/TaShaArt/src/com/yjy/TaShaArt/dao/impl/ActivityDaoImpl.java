package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.ActivityDao;
import com.yjy.TaShaArt.entity.Activity;

public class ActivityDaoImpl extends BaseDaoImpl<Activity> implements ActivityDao {

}
