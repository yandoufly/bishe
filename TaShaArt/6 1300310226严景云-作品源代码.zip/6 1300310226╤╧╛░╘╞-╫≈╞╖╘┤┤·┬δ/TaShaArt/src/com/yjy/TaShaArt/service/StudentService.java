package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Student;

public interface StudentService extends BaseService<Student>{
}
