package com.yjy.TaShaArt.action;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Message;
import com.yjy.TaShaArt.entity.News;
import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.service.NewsService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class NewsAction extends BaseAction {
	@Resource
	private NewsService newsService;
	private News news;
	
	public void findNewsTop10Show() throws IOException {
		String hql = "select new News(id, title) from News where type=? order by id desc limit 9";
		List<Object> parameters = new ArrayList<Object>();
		parameters.add(news.getType());
		List<News> list = newsService.findObjects(hql, parameters);
		/*for(News news : list) {
			System.out.println(news.getTitle());
		}*/
		JSONArray jsonArray = JSONArray.fromObject(list);
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}
	
	
	public void findNewsByIdShow() throws IOException{
		news = newsService.findObjectById(news.getId());
		
		//上一篇
		String hql1 = "select new News(id, title) from News where id in (select max(id) from News where id < ? and type=?)";
		List<Object> parameters1 = new ArrayList<Object>();
		parameters1.add(news.getId());
		parameters1.add(news.getType());
		List<News> list1 = newsService.findObjects(hql1, parameters1);
		News preNews = new News();
		if(list1 != null && list1.size() > 0){
			preNews = list1.get(0);
		}
		
		//下一篇
		String hql2 = "select new News(id, title) from News where id in (select min(id) from News where id > ? and type=?)";
		List<Object> parameters2 = new ArrayList<Object>();
		parameters2.add(news.getId());
		parameters2.add(news.getType());
		List<News> list2 = newsService.findObjects(hql2, parameters2);
		News afterNews = new News();
		if(list2 != null && list2.size() > 0){
			afterNews = list2.get(0);
		}
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(news);
		jsonArray.add(preNews);
		jsonArray.add(afterNews);
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
		
	}
	
	public void findNewsShow() throws IOException{
		QueryHelper queryHelper = new QueryHelper(News.class, "n");
		queryHelper.addCondition("n.type=?", news.getType());
		pageResult = newsService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(jsonArray2);
		jsonArray.add(pageResult.getPageNo());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}

	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(News.class, "u");
		try {
			pageResult = newsService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(news != null){
			news.setCreateTime(new Date());
			newsService.save(news);
		}
		return "list";
	}
	//跳转到编辑页面
	public String editUI(){
		if (news != null && news.getId() != null) {
			news = newsService.findObjectById(news.getId());
			ServletActionContext.getRequest().setAttribute("news", news);
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(news != null){
			newsService.update(news);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(news != null && news.getId() != null){
			newsService.delete(news.getId());
		}
		return "list";
	}
	//批量删除
	public String deleteSelected(){
		if(selectedRow != null){
			for(int id: selectedRow){
				System.out.println("delete id:" + id);
				newsService.delete(id);
			}
		}
		return "list";
	}
	
	public News getNews() {
		return news;
	}
	public void setNews(News news) {
		this.news = news;
	}
}
