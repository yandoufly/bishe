package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.StudentDao;
import com.yjy.TaShaArt.entity.Student;
import com.yjy.TaShaArt.service.StudentService;

@Service("studentService")
public class StudentServiceImpl extends BaseServiceImpl<Student> implements StudentService {
	
	private StudentDao studentDao;
	
	@Resource 
	public void setStudentDao(StudentDao studentDao) {
		super.setBaseDao(studentDao);
		this.studentDao = studentDao;
	}
}
