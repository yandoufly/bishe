package com.yjy.TaShaArt.entity;

import java.util.Date;
/**
 * 存放单页面信息
 */
public class SimplePage {
	private Integer id;
	private String type; //页面标识
	private String typeName; //页面名字
	private String userName; //编辑人
	private String content; //页面内容
	private Date createTime; //创建时间
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeName() {
		return typeName;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	@Override
	public String toString() {
		return "SimplePage [id=" + id + ", type=" + type + ", typeName=" + typeName + ", userName=" + userName
				+ ", content=" + content + ", createTime=" + createTime + "]";
	}
}
