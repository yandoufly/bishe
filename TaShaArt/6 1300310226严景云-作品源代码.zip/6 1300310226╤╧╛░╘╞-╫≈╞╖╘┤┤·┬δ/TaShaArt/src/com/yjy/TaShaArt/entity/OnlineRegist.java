package com.yjy.TaShaArt.entity;

public class OnlineRegist {
	private Integer id;
	private String name; //姓名
	private boolean gender; //性别
	private String cardNo; //身份证号
	private String email; //邮箱
	private String cellphone; //手机号码
	private String graduation; //曾就读于
	private String postcode; //邮政编码
	private String address; //家庭地址
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isGender() {
		return gender;
	}
	public void setGender(boolean gender) {
		this.gender = gender;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCellphone() {
		return cellphone;
	}
	public void setCellphone(String cellphone) {
		this.cellphone = cellphone;
	}
	public String getGraduation() {
		return graduation;
	}
	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}
	public String getPostcode() {
		return postcode;
	}
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "OnlineRegist [id=" + id + ", name=" + name + ", gender=" + gender + ", cardNo=" + cardNo + ", email="
				+ email + ", cellphone=" + cellphone + ", graduation=" + graduation + ", postcode=" + postcode
				+ ", address=" + address + "]";
	}
}
