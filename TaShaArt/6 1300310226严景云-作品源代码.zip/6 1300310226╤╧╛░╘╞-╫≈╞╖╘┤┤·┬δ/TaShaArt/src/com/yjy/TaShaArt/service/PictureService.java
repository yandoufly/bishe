package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Picture;

public interface PictureService extends BaseService<Picture>{

}
