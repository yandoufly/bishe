package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Message;

public interface MessageDao extends BaseDao<Message> {
	
}
