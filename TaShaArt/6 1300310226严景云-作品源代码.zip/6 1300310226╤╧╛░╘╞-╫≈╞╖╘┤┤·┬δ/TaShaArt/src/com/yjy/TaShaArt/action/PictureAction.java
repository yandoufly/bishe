package com.yjy.TaShaArt.action;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Picture;
import com.yjy.TaShaArt.entity.Teacher;
import com.yjy.TaShaArt.service.PictureService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class PictureAction extends BaseAction {
	@Resource
	private PictureService pictureService;
	private Picture picture;
	
	public void findPictureShow() throws IOException{
		System.out.println(picture.getType());
		
		QueryHelper queryHelper = new QueryHelper(Picture.class, "p");
		queryHelper.addCondition("p.type=?", picture.getType());
		pageResult = pictureService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		
		System.out.println("total:" + pageResult.getItems().size());
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(pageResult.getPageNo());
		jsonArray.add(pageResult.getTotalPageCount());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}
	
	
	public Picture getPicture() {
		return picture;
	}
	public void setPicture(Picture picture) {
		this.picture = picture;
	}
}
