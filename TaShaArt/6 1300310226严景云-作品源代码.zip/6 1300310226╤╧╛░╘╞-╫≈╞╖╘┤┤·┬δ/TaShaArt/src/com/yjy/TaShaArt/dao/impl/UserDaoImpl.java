package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.UserDao;
import com.yjy.TaShaArt.entity.User;

public class UserDaoImpl extends BaseDaoImpl<User> implements UserDao {

}
