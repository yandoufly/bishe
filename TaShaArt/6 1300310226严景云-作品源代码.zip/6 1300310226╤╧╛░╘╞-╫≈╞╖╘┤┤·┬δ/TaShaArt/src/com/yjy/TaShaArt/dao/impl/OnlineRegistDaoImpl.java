package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.OnlineRegistDao;
import com.yjy.TaShaArt.entity.OnlineRegist;

public class OnlineRegistDaoImpl extends BaseDaoImpl<OnlineRegist> implements OnlineRegistDao {

}
