package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.MessageDao;
import com.yjy.TaShaArt.entity.Message;
import com.yjy.TaShaArt.service.MessageService;

@Service("messageService")
public class MessageServiceImpl extends BaseServiceImpl<Message> implements MessageService {
	
	private MessageDao messageDao;
	
	@Resource 
	public void setMessageDao(MessageDao messageDao) {
		super.setBaseDao(messageDao);
		this.messageDao = messageDao;
	}
}
