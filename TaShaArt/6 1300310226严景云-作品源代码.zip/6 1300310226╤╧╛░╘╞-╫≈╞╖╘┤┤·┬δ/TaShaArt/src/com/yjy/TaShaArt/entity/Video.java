package com.yjy.TaShaArt.entity;

import java.util.Date;

public class Video {
	private Integer id;
	private String title; //题目
	private String videoImg; //视频图片
	private String directory; //视频目录
	private String descride; //描述
	private Date createTime; //创建时间
	private int scanCount; //浏览次数
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getVideoImg() {
		return videoImg;
	}
	public void setVideoImg(String videoImg) {
		this.videoImg = videoImg;
	}
	public String getDirectory() {
		return directory;
	}
	public void setDirectory(String directory) {
		this.directory = directory;
	}
	public String getDescride() {
		return descride;
	}
	public void setDescride(String descride) {
		this.descride = descride;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public int getScanCount() {
		return scanCount;
	}
	public void setScanCount(int scanCount) {
		this.scanCount = scanCount;
	}
}
