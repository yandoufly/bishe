package com.yjy.TaShaArt.action;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Message;
import com.yjy.TaShaArt.entity.Teacher;
import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.service.TeacherService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class TeacherAction extends BaseAction {
	@Resource
	private TeacherService teacherService;
	private Teacher teacher;
	
	//头像
	private File headImg;
	private String headImgContentType;
	private String headImgFileName;
	
	public void findTeacherShow() throws IOException{
		QueryHelper queryHelper = new QueryHelper(Teacher.class, "t");
		queryHelper.addCondition("t.type=?", teacher.getType());
		pageResult = teacherService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(jsonArray2);
		jsonArray.add(pageResult.getPageNo());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}
	
	public void findTeacherByIdShow() throws IOException {
		if(teacher != null && teacher.getId() != null){
			JSONArray jsonArray = new JSONArray();
			jsonArray.add(teacherService.findObjectById(teacher.getId()));
			
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(jsonArray.toString());
		}
	}
	
	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(Teacher.class, "u");
		try {
			if (teacher != null) {
				if (StringUtils.isNotBlank(teacher.getName())) {
					teacher.setName(URLDecoder.decode(teacher.getName(), "utf-8"));
					queryHelper.addCondition("u.name like ?", "%" + teacher.getName() + "%");
				}
			}
			pageResult = teacherService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(teacher != null){

			//处理头像
			if(headImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/headImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + headImgFileName.substring(headImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(headImg, new File(filePath1, fileName));
				teacher.setHeadImg("upload/headImg/" + fileName);
			}
			teacherService.save(teacher);
		}
		return "list";
	}
	//跳转到编辑页面
	public String editUI(){
		if (teacher != null && teacher.getId() != null) {
			teacher = teacherService.findObjectById(teacher.getId());
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(teacher != null){
			teacherService.update(teacher);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(teacher != null && teacher.getId() != null){
			teacherService.delete(teacher.getId());
		}
		return "list";
	}

	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public File getHeadImg() {
		return headImg;
	}

	public void setHeadImg(File headImg) {
		this.headImg = headImg;
	}

	public String getHeadImgContentType() {
		return headImgContentType;
	}

	public void setHeadImgContentType(String headImgContentType) {
		this.headImgContentType = headImgContentType;
	}

	public String getHeadImgFileName() {
		return headImgFileName;
	}

	public void setHeadImgFileName(String headImgFileName) {
		this.headImgFileName = headImgFileName;
	}
}
