package com.yjy.TaShaArt.action;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.mail.MessagingException;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.service.UserService;
import com.yjy.TaShaArt.util.QueryHelper;
import com.yjy.TaShaArt.util.SendMail;

import net.sf.json.JSONObject;

public class UserAction extends BaseAction {
	@Resource
	private UserService userService;
	private User user;
	
	//头像
	private File headImg;
	private String headImgContentType;
	private String headImgFileName;
	
	public String login() {
		if(user != null) {
			String hql = "from User u where u.account=? and u.password=?";
			List<Object> parameters = new ArrayList<Object>();
			parameters.add(user.getAccount());
			parameters.add(user.getPassword());
			List<User> users = userService.findObjects(hql, parameters);
			if(users != null && users.size() > 0) {
				user = users.get(0);
				ServletActionContext.getRequest().getSession().setAttribute("user", user); //存入session信息
				return "mainFrame";
			}
		}
		ServletActionContext.getRequest().setAttribute("msg", "账号或密码输入有误！！");
		return "login";
	}
	
	public String alterPasswd(){
		if(user != null){
			User user2 = userService.findObjectById(user.getId());
			user2.setPassword(user.getPassword()); //修改密码
			userService.update(user2);
		}
		ServletActionContext.getRequest().setAttribute("msg", "修改密码成功！！");
		return "login";
	}
	
	public String mainFrame(){
		return "mainFrame";
	}
	
	//发送邮件
	public void sendUserMail() throws Exception {
		if(user == null) {
			return;
		}
		
		Map<String, String> map = new HashMap<String, String>();
		SendMail mail = new SendMail("326015540@qq.com", "jpxicmbuuxkfbhgd"); // 用户名&&验证码
		map.put("mail.smtp.host", "smtp.qq.com"); // 指定发送邮件的主机为 smtp.qq.com
		map.put("mail.smtp.auth", "true"); // 开启认证

		// 处理错误：530 Error: A secure connection is requiered(such as ssl)”
		map.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		map.put("mail.smtp.port", "465");
		map.put("mail.smtp.socketFactory.port", "465");
		
		mail.setPros(map);
		mail.initMessage();
		
		String hql = "from User u where u.account=?";
		List<Object> parameters = new ArrayList<Object>();
		parameters.add(user.getAccount());
		List<User> users = userService.findObjects(hql, parameters);
		if(users != null && users.size() > 0) {
			user = users.get(0);
		}
		
		//添加收件人邮箱
		mail.setRecipient(user.getEmail());
		
		mail.setSubject("修改用户密码验证码验证"); // 邮件主题.
		mail.setDate(new Date()); // 邮件时间
		mail.setFrom("塔莎艺术培训学校");  //发送人名字
		int authCode = (int)((Math.random()*9+1)*100000); //随机生成六位数
		System.out.println(authCode); 
		
		mail.setContent(String.valueOf(authCode) , "text/html; charset=UTF-8"); //正文部分
		
		mail.sendMessage(); //发送邮件
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html; charset=utf-8");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", user.getId());
		jsonObject.put("authCode", String.valueOf(authCode));
		jsonObject.put("msg", "已经发送邮件到"+user.getEmail() + "中，请查看验证码");
		response.getWriter().println(jsonObject);
	}
	
	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(User.class, "u");
		try {
			if (user != null) {
				if (StringUtils.isNotBlank(user.getName())) {
					user.setName(URLDecoder.decode(user.getName(), "utf-8"));
					queryHelper.addCondition("u.name like ?", "%" + user.getName() + "%");
				}
			}
			pageResult = userService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(user != null){
			
			//处理头像
			if(headImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/headImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + headImgFileName.substring(headImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(headImg, new File(filePath1, fileName));
				user.setHeadImg("upload/headImg/" + fileName);
			}
			userService.save(user);
		}
		return "list";
	}
	//跳转到编辑页面
	public String editUI(){
		if (user != null && user.getId() != null) {
			user = userService.findObjectById(user.getId());
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(user != null){
			userService.update(user);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(user != null && user.getId() != null){
			userService.delete(user.getId());
		}
		return "list";
	}
	//批量删除
	public String deleteSelected(){
		if(selectedRow != null){
			for(int id: selectedRow){
				System.out.println("delete id:" + id);
				userService.delete(id);
			}
		}
		return "list";
	}
	
	
	public void setUser(User user) {
		this.user = user;
	}
	public User getUser() {
		return user;
	}

	public File getHeadImg() {
		return headImg;
	}
	public void setHeadImg(File headImg) {
		this.headImg = headImg;
	}
	public String getHeadImgContentType() {
		return headImgContentType;
	}
	public void setHeadImgContentType(String headImgContentType) {
		this.headImgContentType = headImgContentType;
	}
	public String getHeadImgFileName() {
		return headImgFileName;
	}
	public void setHeadImgFileName(String headImgFileName) {
		this.headImgFileName = headImgFileName;
	}
}
