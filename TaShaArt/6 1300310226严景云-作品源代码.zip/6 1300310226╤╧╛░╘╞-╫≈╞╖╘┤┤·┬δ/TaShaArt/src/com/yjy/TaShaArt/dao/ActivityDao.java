package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Activity;

public interface ActivityDao extends BaseDao<Activity> {
	
}
