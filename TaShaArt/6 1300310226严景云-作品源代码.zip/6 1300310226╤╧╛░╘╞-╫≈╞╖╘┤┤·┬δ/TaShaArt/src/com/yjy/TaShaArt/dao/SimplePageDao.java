package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.SimplePage;

public interface SimplePageDao extends BaseDao<SimplePage> {
	
}
