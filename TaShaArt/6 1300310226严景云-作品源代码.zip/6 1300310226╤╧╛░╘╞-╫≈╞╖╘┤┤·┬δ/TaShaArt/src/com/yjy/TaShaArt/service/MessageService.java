package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Message;

public interface MessageService extends BaseService<Message>{

}
