package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.User;

public interface UserService extends BaseService<User>{

}
