package com.yjy.TaShaArt.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.SimplePage;
import com.yjy.TaShaArt.service.SimplePageService;

import net.sf.json.JSONArray;

public class SimplePageAction extends BaseAction {
	@Resource
	private SimplePageService simplePageService;
	private SimplePage simplePage;
	private String type;
	
	public String findSimplePage(){
		String hql = "from SimplePage sp where sp.type=?";
		List<Object> parameters = new ArrayList<Object>();
		parameters.add(type);
		List<SimplePage> list = simplePageService.findObjects(hql, parameters);
		if(list != null && list.size() > 0) {
			simplePage = list.get(0);
			ServletActionContext.getRequest().setAttribute("simplePage", simplePage);
			
		}
		return type;
	}
	
	public void editSimplePage() throws IOException{
		if(simplePage != null){
			simplePage.setCreateTime(new Date());
			if(simplePage.getId() != null){
				simplePageService.update(simplePage);
			} else {
				simplePageService.save(simplePage);
			}
		}
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write("编辑成功");
	}
	
	public void findSimplePageShow() throws IOException{
		String hql = "from SimplePage sp where sp.type=?";
		List<Object> parameters = new ArrayList<Object>();
		parameters.add(type);
		List<SimplePage> list = simplePageService.findObjects(hql, parameters);
		if(list != null && list.size() > 0) {
			JSONArray jsonArray = JSONArray.fromObject(list);
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setContentType("text/xml;charset=UTF-8");
			response.getWriter().write(jsonArray.toString());
		}
	}
	
	public void setSimplePage(SimplePage simplePage) {
		this.simplePage = simplePage;
	}
	public SimplePage getSimplePage() {
		return simplePage;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
}
