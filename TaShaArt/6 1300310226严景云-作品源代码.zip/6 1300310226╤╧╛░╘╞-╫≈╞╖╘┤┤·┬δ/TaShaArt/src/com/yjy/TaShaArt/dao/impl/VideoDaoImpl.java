package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.VideoDao;
import com.yjy.TaShaArt.entity.Video;

public class VideoDaoImpl extends BaseDaoImpl<Video> implements VideoDao {

}
