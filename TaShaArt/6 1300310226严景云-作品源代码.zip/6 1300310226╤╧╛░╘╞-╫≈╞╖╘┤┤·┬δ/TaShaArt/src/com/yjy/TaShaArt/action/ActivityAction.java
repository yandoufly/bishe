package com.yjy.TaShaArt.action;

import java.io.IOException;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Activity;
import com.yjy.TaShaArt.service.ActivityService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class ActivityAction extends BaseAction {

	private static final long serialVersionUID = 1L;
	
	@Resource
	private ActivityService activityService;
	private Activity activity;
	
	public void findActivityShow() throws IOException {
		QueryHelper queryHelper = new QueryHelper(Activity.class, "u");
		pageResult = activityService.getPageResult(queryHelper, getPageNo(), getPageSize());
		JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
		JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
		
		JSONArray jsonArray = new JSONArray();
		jsonArray.add(jsonArray1);
		jsonArray.add(jsonArray2);
		jsonArray.add(pageResult.getPageNo());
		
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().write(jsonArray.toString());
	}

	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(Activity.class, "u");
		try {
			pageResult = activityService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(activity != null){
			activity.setCreateTime(new Date());
			activityService.save(activity);
		}
		return "list";
	}
	//跳转到编辑页面
	public String editUI(){
		if (activity != null && activity.getId() != null) {
			activity = activityService.findObjectById(activity.getId());
			ServletActionContext.getRequest().setAttribute("activity", activity);
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(activity != null){
			activityService.update(activity);
		}
		return "list";
	}
	//删除
	public String delete(){
		if(activity != null && activity.getId() != null){
			activityService.delete(activity.getId());
		}
		return "list";
	}
	
	public Activity getActivity() {
		return activity;
	}
	public void setActivity(Activity activity) {
		this.activity = activity;
	}
}
