package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.User;

public interface UserDao extends BaseDao<User> {
	
}
