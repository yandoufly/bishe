package com.yjy.TaShaArt.entity;

public class Message {
	private Integer id;
	private String userName; //用户名
	private String email; //邮箱
	private String mobile; //手机
	private String qq; //QQ
	private boolean publish; //是否发布到网站
	private String question; //留言
	private String answer; //解答留言
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getQq() {
		return qq;
	}
	public void setQq(String qq) {
		this.qq = qq;
	}
	public boolean isPublish() {
		return publish;
	}
	public void setPublish(boolean publish) {
		this.publish = publish;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "Message [id=" + id + ", userName=" + userName + ", email=" + email + ", mobile=" + mobile + ", qq=" + qq
				+ ", publish=" + publish + ", question=" + question + ", answer=" + answer + "]";
	}
}
