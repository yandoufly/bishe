package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Video;

public interface VideoService extends BaseService<Video>{

}
