package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.MessageDao;
import com.yjy.TaShaArt.entity.Message;

public class MessageDaoImpl extends BaseDaoImpl<Message> implements MessageDao {

}
