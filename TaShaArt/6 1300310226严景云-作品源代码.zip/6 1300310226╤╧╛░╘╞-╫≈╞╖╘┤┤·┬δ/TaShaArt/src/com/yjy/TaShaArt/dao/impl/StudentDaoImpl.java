package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.StudentDao;
import com.yjy.TaShaArt.entity.Student;

public class StudentDaoImpl extends BaseDaoImpl<Student> implements StudentDao {

}
