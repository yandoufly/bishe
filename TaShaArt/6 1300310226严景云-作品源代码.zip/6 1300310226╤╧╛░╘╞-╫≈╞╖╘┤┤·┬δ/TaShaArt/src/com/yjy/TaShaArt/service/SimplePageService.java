package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.SimplePage;

public interface SimplePageService extends BaseService<SimplePage>{

}
