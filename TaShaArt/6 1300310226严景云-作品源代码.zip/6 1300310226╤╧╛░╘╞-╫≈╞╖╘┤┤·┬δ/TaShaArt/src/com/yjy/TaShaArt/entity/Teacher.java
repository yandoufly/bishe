package com.yjy.TaShaArt.entity;

public class Teacher {
	private Integer id;
	private String type; //教师类型:行政人员、音乐教师、传媒教师、舞蹈教师
	private String name; //名字
	private String headImg; //头像
	private String mobile; //手机
	private String jobTitle; //职称
	private String school; //毕业学校
	private String introduction; //个人简介
	private String features; //教学特点
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHeadImg() {
		return headImg;
	}
	public void setHeadImg(String headImg) {
		this.headImg = headImg;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getFeatures() {
		return features;
	}
	public void setFeatures(String features) {
		this.features = features;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", type=" + type + ", name=" + name + ", mobile=" + mobile + ", jobTitle="
				+ jobTitle + ", school=" + school + ", introduction=" + introduction + ", features=" + features + "]";
	}
}
