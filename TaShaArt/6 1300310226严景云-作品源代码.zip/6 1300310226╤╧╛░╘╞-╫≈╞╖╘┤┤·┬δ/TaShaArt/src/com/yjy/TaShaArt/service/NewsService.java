package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.News;

public interface NewsService extends BaseService<News>{

}
