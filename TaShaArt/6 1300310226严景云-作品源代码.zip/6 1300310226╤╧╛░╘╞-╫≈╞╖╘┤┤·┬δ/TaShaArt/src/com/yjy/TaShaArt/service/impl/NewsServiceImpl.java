package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.NewsDao;
import com.yjy.TaShaArt.entity.News;
import com.yjy.TaShaArt.service.NewsService;

@Service("newsService")
public class NewsServiceImpl extends BaseServiceImpl<News> implements NewsService {
	
	private NewsDao newsDao;
	
	@Resource 
	public void setNewsDao(NewsDao newsDao) {
		super.setBaseDao(newsDao);
		this.newsDao = newsDao;
	}
}
