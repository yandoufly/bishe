package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Video;

public interface VideoDao extends BaseDao<Video> {
	
}
