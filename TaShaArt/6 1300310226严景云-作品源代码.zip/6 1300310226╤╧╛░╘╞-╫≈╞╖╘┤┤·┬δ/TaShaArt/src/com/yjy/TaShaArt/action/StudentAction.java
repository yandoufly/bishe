package com.yjy.TaShaArt.action;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.ServletActionContext;

import com.yjy.TaShaArt.entity.Message;
import com.yjy.TaShaArt.entity.Student;
import com.yjy.TaShaArt.entity.User;
import com.yjy.TaShaArt.service.StudentService;
import com.yjy.TaShaArt.util.QueryHelper;

import net.sf.json.JSONArray;

public class StudentAction extends BaseAction {

	private static final long serialVersionUID = 1L;
	
	@Resource
	private StudentService studentService;
	private Student student;
	

	//头像
	private File headImg;
	private String headImgContentType;
	private String headImgFileName;
	

	//头像
	private File universityImg;
	private String universityImgContentType;
	private String universityImgFileName;
	
	
	public void findStudentShow() throws IOException {
		if(student != null) {
			System.out.println(student.getType() + " 学生类型");
			
			QueryHelper queryHelper = new QueryHelper(Student.class, "s");
			queryHelper.addCondition("s.type=?", student.getType());
			pageResult = studentService.getPageResult(queryHelper, getPageNo(), getPageSize());
			
			JSONArray jsonArray1 = JSONArray.fromObject(pageResult.getItems()); //得到数据
			JSONArray jsonArray2 = JSONArray.fromObject(pageResult.getPageList()); //得到页数列表
			
			JSONArray jsonArray = new JSONArray();
			jsonArray.add(jsonArray1);
			jsonArray.add(jsonArray2);
			jsonArray.add(pageResult.getPageNo());
			
			HttpServletResponse response = ServletActionContext.getResponse();
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().write(jsonArray.toString());
		}
		
	}
	
	// 列表页面
	public String listUI() throws Exception {
		QueryHelper queryHelper = new QueryHelper(Student.class, "s");
		try {
			if (student != null) {
				if (StringUtils.isNotBlank(student.getName())) {
					student.setName(URLDecoder.decode(student.getName(), "utf-8"));
					queryHelper.addCondition("s.name like ?", "%" + student.getName() + "%");
				}
			}
			pageResult = studentService.getPageResult(queryHelper, getPageNo(), getPageSize());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		ServletActionContext.getRequest().setAttribute("pageResult", pageResult);
		return "listUI";
	}

	//跳转到新增页面
	public String addUI(){
		return "addUI";
	}
	//保存新增
	public String add() throws Exception{
		if(student != null){
			
			//处理头像
			if(headImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/studentImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + headImgFileName.substring(headImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(headImg, new File(filePath1, fileName));
				student.setHeadImg("upload/studentImg/" + fileName);
			}
			
			//处理学校录取通知书(图)
			if(universityImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/studentImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + universityImgFileName.substring(universityImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(universityImg, new File(filePath1, fileName));
				student.setAccessUniversity("upload/studentImg/" + fileName);
			}
			studentService.save(student);
		}
		return "list";
	}
	
	//跳转到编辑页面
	public String editUI(){
		if (student != null && student.getId() != null) {
			student = studentService.findObjectById(student.getId());
		}
		return "editUI";
	}
	//保存编辑
	public String edit() throws Exception{
		if(student != null){

			//处理学校录取通知书(图)
			if(universityImg != null){
				String filePath1 = "D:/workspace/TaShaArt/WebContent/upload/studentImg";
				String fileName = UUID.randomUUID().toString().replaceAll("-", "") + universityImgFileName.substring(universityImgFileName.lastIndexOf("."));
				
				FileUtils.copyFile(universityImg, new File(filePath1, fileName));
				student.setAccessUniversity("upload/studentImg/" + fileName);
			}
			studentService.update(student);
		}
		return "list";
	}
	
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}

	public File getHeadImg() {
		return headImg;
	}

	public void setHeadImg(File headImg) {
		this.headImg = headImg;
	}

	public String getHeadImgContentType() {
		return headImgContentType;
	}

	public void setHeadImgContentType(String headImgContentType) {
		this.headImgContentType = headImgContentType;
	}

	public String getHeadImgFileName() {
		return headImgFileName;
	}

	public void setHeadImgFileName(String headImgFileName) {
		this.headImgFileName = headImgFileName;
	}

	public File getUniversityImg() {
		return universityImg;
	}

	public void setUniversityImg(File universityImg) {
		this.universityImg = universityImg;
	}

	public String getUniversityImgContentType() {
		return universityImgContentType;
	}

	public void setUniversityImgContentType(String universityImgContentType) {
		this.universityImgContentType = universityImgContentType;
	}

	public String getUniversityImgFileName() {
		return universityImgFileName;
	}

	public void setUniversityImgFileName(String universityImgFileName) {
		this.universityImgFileName = universityImgFileName;
	}
}
