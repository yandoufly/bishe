package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.OnlineRegistDao;
import com.yjy.TaShaArt.entity.OnlineRegist;
import com.yjy.TaShaArt.service.OnlineRegistService;

@Service("onlineRegistService")
public class OnlineRegistServiceImpl extends BaseServiceImpl<OnlineRegist> implements OnlineRegistService {
	
	private OnlineRegistDao onlineRegistDao;
	
	@Resource 
	public void setOnlineRegistDao(OnlineRegistDao onlineRegistDao) {
		super.setBaseDao(onlineRegistDao);
		this.onlineRegistDao = onlineRegistDao;
	}
}
