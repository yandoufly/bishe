package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Picture;

public interface PictureDao extends BaseDao<Picture> {
	
}
