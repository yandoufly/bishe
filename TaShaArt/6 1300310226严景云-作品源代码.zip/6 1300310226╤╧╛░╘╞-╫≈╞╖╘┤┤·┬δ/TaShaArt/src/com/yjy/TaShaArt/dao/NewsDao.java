package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.News;

public interface NewsDao extends BaseDao<News> {
	
}
