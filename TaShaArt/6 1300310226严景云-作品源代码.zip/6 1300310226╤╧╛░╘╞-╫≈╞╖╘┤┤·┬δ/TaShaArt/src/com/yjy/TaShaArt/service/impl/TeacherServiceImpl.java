package com.yjy.TaShaArt.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.yjy.TaShaArt.dao.TeacherDao;
import com.yjy.TaShaArt.entity.Teacher;
import com.yjy.TaShaArt.service.TeacherService;

@Service("teacherService")
public class TeacherServiceImpl extends BaseServiceImpl<Teacher> implements TeacherService {
	
	private TeacherDao teacherDao;
	
	@Resource
	public void setTeacherDao(TeacherDao teacherDao) {
		super.setBaseDao(teacherDao);
		this.teacherDao = teacherDao;
	}
}
