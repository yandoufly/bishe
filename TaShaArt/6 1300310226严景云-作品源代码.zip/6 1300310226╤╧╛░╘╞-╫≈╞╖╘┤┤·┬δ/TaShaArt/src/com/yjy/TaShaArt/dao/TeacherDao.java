package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Teacher;

public interface TeacherDao extends BaseDao<Teacher> {
	
}
