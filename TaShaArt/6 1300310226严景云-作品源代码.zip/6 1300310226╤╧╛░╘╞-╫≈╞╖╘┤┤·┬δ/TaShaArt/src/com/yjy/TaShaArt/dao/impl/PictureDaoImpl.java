package com.yjy.TaShaArt.dao.impl;

import com.yjy.TaShaArt.dao.PictureDao;
import com.yjy.TaShaArt.entity.Picture;

public class PictureDaoImpl extends BaseDaoImpl<Picture> implements PictureDao {

}
