package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.Activity;

public interface ActivityService extends BaseService<Activity>{

}
