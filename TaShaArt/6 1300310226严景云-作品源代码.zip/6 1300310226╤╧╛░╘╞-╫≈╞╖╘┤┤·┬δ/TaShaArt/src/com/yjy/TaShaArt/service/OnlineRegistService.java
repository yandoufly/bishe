package com.yjy.TaShaArt.service;

import com.yjy.TaShaArt.entity.OnlineRegist;

public interface OnlineRegistService extends BaseService<OnlineRegist>{

}
