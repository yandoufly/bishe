package com.yjy.TaShaArt.dao;

import com.yjy.TaShaArt.entity.Student;

public interface StudentDao extends BaseDao<Student> {
	
}
