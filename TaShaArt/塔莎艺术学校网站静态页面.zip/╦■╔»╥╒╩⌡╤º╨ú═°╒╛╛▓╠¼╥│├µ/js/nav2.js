$(function(){
	$(".nav .list_1 li").hover(function(){
		$(this).find(".down").stop().slideDown()	
	},function(){
		$(this).find(".down").stop().slideUp()	
	})	
})